"""Single-GPU compatibility launchers for MACORAG RL."""

