from __future__ import annotations

import os
import ast
import logging
from pathlib import Path


def test_single_gpu_launch_config_uses_one_visible_gpu_for_both_processes(tmp_path: Path) -> None:
    from rl_single.launch_config import load_single_gpu_launch_config

    config = tmp_path / "train_grpo.yml"
    config.write_text(
        "\n".join(
            [
                'model_path: "model/Qwen2.5-7B-Instruct"',
                'sft_adapter_path: "outputs/sft/adapter"',
                'vllm_sync_mode: "lora"',
                'vllm_gpu_indices: "0"',
                'gpu_indices: "1"',
                "vllm_port: 8123",
                "vllm_gpu_memory_utilization: 0.75",
                "vllm_max_model_len: 8192",
                'single_vllm_quantization: "bitsandbytes"',
                'single_vllm_load_format: "bitsandbytes"',
                "single_vllm_enforce_eager: true",
            ]
        ),
        encoding="utf-8",
    )

    launch = load_single_gpu_launch_config(
        config_path=config,
        single_gpu_index="3",
        vllm_gpu_memory_utilization="0.45",
    )

    assert launch.visible_gpu == "3"
    assert launch.train_env["CUDA_VISIBLE_DEVICES"] == "3"
    assert launch.vllm_env["CUDA_VISIBLE_DEVICES"] == "3"
    assert launch.nproc_per_node == 1
    assert launch.vllm_args["model"] == "model/Qwen2.5-7B-Instruct"
    assert launch.vllm_args["port"] == "8123"
    assert launch.vllm_args["gpu_memory_utilization"] == "0.45"
    assert launch.vllm_args["lora_adapter_path"] == "outputs/sft/adapter"
    assert launch.vllm_args["mode"] == "colocate"
    assert launch.vllm_args["quantization"] == "bitsandbytes"
    assert launch.vllm_args["load_format"] == "bitsandbytes"
    assert launch.vllm_args["enforce_eager"] == "True"


def test_single_gpu_config_file_defaults_to_colocate_on_one_gpu() -> None:
    from rl_single.launch_config import load_single_gpu_launch_config
    import yaml

    config = Path(__file__).resolve().parent / "train_grpo_single.yml"
    launch = load_single_gpu_launch_config(config_path=config)
    payload = yaml.safe_load(config.read_text(encoding="utf-8"))

    assert config.exists()
    assert launch.visible_gpu == "0"
    assert launch.nproc_per_node == 1
    assert launch.vllm_args["mode"] == "colocate"
    assert launch.vllm_args["sync_mode"] == "dense"
    assert launch.vllm_args["tensor_parallel_size"] == "1"
    assert launch.vllm_args["quantization"] == ""
    assert launch.vllm_args["load_format"] == "auto"
    assert payload["load_4bit"] is False
    assert payload["bf16"] is True


def test_train_wrapper_skips_only_vllm_gpu_overlap_check(monkeypatch) -> None:
    import rl_single.train_single_gpu as train_single_gpu

    calls: list[str] = []

    class FakeEntrypoint:
        def __init__(self) -> None:
            self._validate_vllm_gpu_placement = lambda args: calls.append("original")

        def main(self) -> None:
            self._validate_vllm_gpu_placement(object())
            calls.append("main")

    fake = FakeEntrypoint()
    monkeypatch.setattr(train_single_gpu, "_load_entrypoint", lambda: fake)
    monkeypatch.setattr(train_single_gpu, "_patch_colocated_vllm_client", lambda: calls.append("patch"))

    train_single_gpu.main()

    assert calls == ["patch", "main"]


def test_colocated_vllm_client_generates_token_ids_without_server(monkeypatch) -> None:
    import rl_single.train_single_gpu as train_single_gpu

    created: list[dict[str, object]] = []
    generate_calls: list[tuple[list[str], object]] = []

    class FakeSamplingParams:
        def __init__(self, **kwargs: object) -> None:
            self.kwargs = kwargs

    class FakeOutput:
        token_ids = [11, 22]

    class FakeRequestOutput:
        outputs = [FakeOutput()]

    class FakeLLM:
        def __init__(self, **kwargs: object) -> None:
            created.append(kwargs)

        def generate(self, prompts: list[str], *, sampling_params: object, use_tqdm: bool) -> list[FakeRequestOutput]:
            generate_calls.append((prompts, sampling_params))
            assert use_tqdm is False
            return [FakeRequestOutput()]

    monkeypatch.setattr(train_single_gpu, "LLM", FakeLLM)
    monkeypatch.setattr(train_single_gpu, "SamplingParams", FakeSamplingParams)

    client = train_single_gpu.ColocatedVLLMGenerationClient(
        model_path="model/Qwen2.5-7B-Instruct",
        tensor_parallel_size=1,
        gpu_memory_utilization=0.3,
        max_model_len=4096,
        dtype="auto",
    )

    token_ids, text = client.generate("question", max_tokens=32, temperature=0.7, top_p=0.9, top_k=5)

    assert token_ids == [11, 22]
    assert text == ""
    assert created == [
        {
            "model": "model/Qwen2.5-7B-Instruct",
            "tensor_parallel_size": 1,
            "gpu_memory_utilization": 0.3,
            "max_model_len": 4096,
            "dtype": "auto",
            "quantization": None,
            "load_format": "auto",
            "enforce_eager": None,
        }
    ]
    assert generate_calls[0][0] == ["question"]
    assert generate_calls[0][1].kwargs["max_tokens"] == 32


def test_colocated_vllm_client_syncs_dense_weights_into_embedded_llm() -> None:
    import rl_single.train_single_gpu as train_single_gpu

    loaded: list[tuple[str, object]] = []

    class FakeVLLMModel:
        def load_weights(self, weights: list[tuple[str, object]]) -> None:
            loaded.extend(weights)

    class FakeBackend:
        llm_engine = type(
            "Engine",
            (),
            {
                "model_executor": type(
                    "Executor",
                    (),
                    {
                        "driver_worker": type(
                            "Worker",
                            (),
                            {"model_runner": type("Runner", (), {"model": FakeVLLMModel()})()},
                        )()
                    },
                )()
            },
        )()

    class FakeParameter:
        def __init__(self, data: object) -> None:
            self.data = data

    class FakeModel:
        def named_parameters(self) -> list[tuple[str, FakeParameter]]:
            return [("model.layers.0.weight", FakeParameter("tensor"))]

    client = train_single_gpu.ColocatedVLLMGenerationClient(backend=FakeBackend())
    elapsed = client.sync_trainable_parameters(FakeModel())

    assert elapsed >= 0.0
    assert loaded == [("model.layers.0.weight", "tensor")]


def test_colocated_vllm_client_syncs_with_v1_inprocess_engine_shape() -> None:
    import rl_single.train_single_gpu as train_single_gpu

    loaded: list[tuple[str, object]] = []

    class FakeVLLMModel:
        def load_weights(self, weights: list[tuple[str, object]]) -> None:
            loaded.extend(weights)

    model_executor = type(
        "Executor",
        (),
        {
            "driver_worker": type(
                "Worker",
                (),
                {"model_runner": type("Runner", (), {"model": FakeVLLMModel()})()},
            )()
        },
    )()
    engine_core = type("EngineCore", (), {"model_executor": model_executor})()

    class FakeBackend:
        llm_engine = type(
            "V1Engine",
            (),
            {"engine_core": type("Client", (), {"engine_core": engine_core})()},
        )()

    class FakeParameter:
        data = "tensor"

    class FakeModel:
        def named_parameters(self) -> list[tuple[str, FakeParameter]]:
            return [("model.layers.0.weight", FakeParameter())]

    client = train_single_gpu.ColocatedVLLMGenerationClient(backend=FakeBackend())
    client.sync_trainable_parameters(FakeModel())

    assert loaded == [("model.layers.0.weight", "tensor")]


def test_train_script_disables_vllm_v1_multiprocessing_for_colocate() -> None:
    script = (Path(__file__).resolve().parent / "run_train_grpo_single.sh").read_text(encoding="utf-8")

    assert "VLLM_ENABLE_V1_MULTIPROCESSING" in script
    assert "VLLM_USE_V1" not in script


def test_single_gpu_build_policy_syncs_before_first_rollout(monkeypatch) -> None:
    import rl_single.train_single_gpu as train_single_gpu

    calls: list[tuple[str, object]] = []

    class FakeClient(train_single_gpu.ColocatedVLLMGenerationClient):
        def __init__(self) -> None:
            pass

        def sync_trainable_parameters(self, model: object) -> float:
            calls.append(("sync", model))
            return 0.0

    class FakePolicy:
        vllm_client = FakeClient()

    class FakeEntrypoint:
        def _build_policy(self, args: object, raw_policy_model: object, tokenizer: object) -> FakePolicy:
            calls.append(("build", raw_policy_model))
            return FakePolicy()

    entrypoint = FakeEntrypoint()
    train_single_gpu._patch_initial_vllm_sync(entrypoint)

    model = object()
    policy = entrypoint._build_policy(object(), model, object())

    assert isinstance(policy, FakePolicy)
    assert calls == [("build", model), ("sync", model)]


def test_single_gpu_dense_sync_rejects_4bit_policy_before_vllm_load() -> None:
    from argparse import Namespace

    import pytest

    import rl_single.train_single_gpu as train_single_gpu

    class FakePolicy:
        vllm_client = train_single_gpu.ColocatedVLLMGenerationClient(backend=object())

    class FakeEntrypoint:
        def _build_policy(self, args: object, raw_policy_model: object, tokenizer: object) -> FakePolicy:
            return FakePolicy()

    entrypoint = FakeEntrypoint()
    train_single_gpu._patch_initial_vllm_sync(entrypoint)

    with pytest.raises(SystemExit, match="load_4bit: false"):
        entrypoint._build_policy(Namespace(vllm_sync_mode="dense", load_4bit=True), object(), object())


def test_script_files_are_kept_inside_rl_single() -> None:
    root = Path(__file__).resolve().parent

    assert (root / "run_vllm_server_single.sh").exists()
    assert (root / "run_train_grpo_single.sh").exists()
    assert os.access(root / "run_vllm_server_single.sh", os.X_OK)
    assert os.access(root / "run_train_grpo_single.sh", os.X_OK)


def test_train_script_uses_direct_python_in_single_gpu_mode() -> None:
    script = (Path(__file__).resolve().parent / "run_train_grpo_single.sh").read_text(encoding="utf-8")

    assert "torchrun" not in script
    assert '-m rl_single.train_single_gpu --config "${CONFIG_PATH}"' in script


def test_train_script_defaults_to_rl_single_config_and_no_server_launcher() -> None:
    script = (Path(__file__).resolve().parent / "run_train_grpo_single.sh").read_text(encoding="utf-8")

    assert "train_grpo_single.yml" in script
    assert "run_vllm_server_single.sh" not in script
    assert "vllm-serve" not in script


def test_single_gpu_wrapper_sanitizes_rl_single_only_config_keys(tmp_path: Path, monkeypatch) -> None:
    import sys

    import yaml

    import rl_single.train_single_gpu as train_single_gpu

    config = tmp_path / "train_grpo_single.yml"
    config.write_text(
        "\n".join(
            [
                'model_path: "model/Qwen2.5-7B-Instruct"',
                "use_vllm_generation: true",
                'single_vllm_quantization: "bitsandbytes"',
                'single_vllm_load_format: "bitsandbytes"',
                "single_vllm_enforce_eager: true",
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(sys, "argv", ["train_single_gpu", "--config", str(config), "--check-only"])

    sanitized = train_single_gpu._sanitize_config_for_single_training()

    assert sanitized is not None
    assert sanitized != config
    payload = yaml.safe_load(sanitized.read_text(encoding="utf-8"))
    assert payload == {"model_path": "model/Qwen2.5-7B-Instruct", "use_vllm_generation": True}
    assert sys.argv[sys.argv.index("--config") + 1] == str(sanitized)


def test_rl_single_does_not_import_rl_training_modules() -> None:
    root = Path(__file__).resolve().parent
    offenders: list[tuple[str, str]] = []
    for path in root.glob("*.py"):
        if path.name.startswith("test_"):
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "rl_training" or alias.name.startswith("rl_training."):
                        offenders.append((path.name, alias.name))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if module == "rl_training" or module.startswith("rl_training."):
                    offenders.append((path.name, module))

    assert offenders == []


def test_single_gpu_entrypoint_loads_local_training_module() -> None:
    text = (Path(__file__).resolve().parent / "train_single_gpu.py").read_text(encoding="utf-8")

    assert "import rl_single.train_grpo_macorag as entrypoint" in text
    assert "rl_training" not in text


def test_single_gpu_training_entrypoint_has_no_console_prints() -> None:
    root = Path(__file__).resolve().parent
    for path in [root / "train_grpo_macorag.py", root / "train_single_gpu.py"]:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        print_calls = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "print"
        ]
        assert print_calls == []


def test_single_gpu_quiet_defaults_raise_noisy_loggers_to_error() -> None:
    import rl_single.train_single_gpu as train_single_gpu

    logger_names = ["", "vllm", "LinearRAG", "httpx", "sentence_transformers"]
    for name in logger_names:
        logging.getLogger(name).setLevel(logging.INFO)

    train_single_gpu._configure_quiet_console_defaults()

    for name in logger_names:
        assert logging.getLogger(name).level >= logging.ERROR


def test_retrieval_engine_creation_suppresses_noisy_info_logs(monkeypatch, tmp_path: Path) -> None:
    import rl_single.retrieval as retrieval

    observed_level: dict[str, int] = {}

    class FakeEngine:
        pass

    def fake_create_linear_rag_query_engine(**kwargs) -> FakeEngine:
        observed_level["LinearRAG"] = logging.getLogger("LinearRAG").level
        observed_level["root"] = logging.getLogger().level
        return FakeEngine()

    monkeypatch.setattr(retrieval, "create_linear_rag_query_engine", fake_create_linear_rag_query_engine)
    logging.getLogger("LinearRAG").setLevel(logging.INFO)
    logging.getLogger().setLevel(logging.INFO)
    env = retrieval.CachedLinearRAGRetrievalEnv(
        retrieval_root=tmp_path,
        embedding_model="embedding",
        spacy_model=None,
        top_k=5,
        max_workers=2,
        batch_size=4,
        use_vectorized_retrieval=True,
    )

    env.prewarm(["hotpotqa"])

    assert observed_level["LinearRAG"] >= logging.ERROR
    assert observed_level["root"] >= logging.ERROR
