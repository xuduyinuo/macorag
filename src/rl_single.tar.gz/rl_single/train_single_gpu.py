from __future__ import annotations

import os
import sys
import tempfile
import time
import logging
from pathlib import Path
from typing import Any

LLM = None
SamplingParams = None

RL_SINGLE_ONLY_CONFIG_KEYS = {
    "single_vllm_quantization",
    "single_vllm_load_format",
    "single_vllm_enforce_eager",
}


def _configure_quiet_console_defaults() -> None:
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
    os.environ.setdefault("VLLM_LOGGING_LEVEL", "ERROR")
    os.environ.setdefault("VLLM_CONFIGURE_LOGGING", "0")
    for logger_name in (
        "",
        "LinearRAG",
        "vllm",
        "httpx",
        "httpcore",
        "urllib3",
        "sentence_transformers",
        "transformers",
        "huggingface_hub",
    ):
        logging.getLogger(logger_name).setLevel(logging.ERROR)


def _with_logger_errors(logger_names: tuple[str, ...], callback: Any) -> Any:
    previous_levels = {name: logging.getLogger(name).level for name in logger_names}
    try:
        for name in logger_names:
            logging.getLogger(name).setLevel(logging.ERROR)
        return callback()
    finally:
        for name, level in previous_levels.items():
            logging.getLogger(name).setLevel(level)


def _skip_vllm_gpu_overlap_check(args: Any) -> None:
    return None


def _as_bool(value: str | None, *, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _as_optional_int(value: str | None) -> int | None:
    if value is None or str(value).strip() == "":
        return None
    return int(value)


def _as_optional_bool(value: str | None) -> bool | None:
    if value is None or value == "":
        return None
    return _as_bool(value)


def _as_optional_str(value: str | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _sanitize_config_for_single_training() -> Path | None:
    if "--config" not in sys.argv:
        return None
    config_index = sys.argv.index("--config") + 1
    if config_index >= len(sys.argv):
        return None
    config_path = Path(sys.argv[config_index])
    if not config_path.exists():
        return None
    try:
        import yaml
    except ModuleNotFoundError as exc:
        raise SystemExit("PyYAML is required to load rl_single YAML config.") from exc
    payload = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        return None
    sanitized = {key: value for key, value in payload.items() if key not in RL_SINGLE_ONLY_CONFIG_KEYS}
    if sanitized == payload:
        return None
    temp = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        suffix=".yml",
        prefix="macorag_rl_single_",
        delete=False,
    )
    with temp:
        yaml.safe_dump(sanitized, temp, allow_unicode=True, sort_keys=False)
    sanitized_path = Path(temp.name)
    sys.argv[config_index] = str(sanitized_path)
    return sanitized_path


def _load_vllm_classes() -> tuple[Any, Any]:
    global LLM, SamplingParams
    if LLM is None or SamplingParams is None:
        os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")
        try:
            from vllm import LLM as VLLMLLM
            from vllm import SamplingParams as VLLMSamplingParams
        except ModuleNotFoundError as exc:
            raise SystemExit("vLLM is required for rl_single colocate generation.") from exc
        LLM = VLLMLLM
        SamplingParams = VLLMSamplingParams
    return LLM, SamplingParams


def _vllm_model_runner(llm: Any) -> Any:
    engine = llm.llm_engine
    model_executor = getattr(engine, "model_executor", None)
    if model_executor is None:
        engine_core_client = getattr(engine, "engine_core", None)
        engine_core = getattr(engine_core_client, "engine_core", None)
        model_executor = getattr(engine_core, "model_executor", None)
    if model_executor is None:
        raise SystemExit(
            "Unable to access the colocated vLLM model executor. "
            "Set VLLM_ENABLE_V1_MULTIPROCESSING=0 before starting rl_single training."
        )
    return model_executor.driver_worker.model_runner.model


def _sync_dense_weights_to_vllm(llm: Any, model: Any) -> None:
    llm_model = _vllm_model_runner(llm)
    if callable(getattr(model, "merge_adapter", None)) and callable(getattr(model, "unmerge_adapter", None)):
        model.merge_adapter()
        try:
            for name, parameter in model.named_parameters():
                name = name.removeprefix("base_model.model.").replace(".base_layer", "")
                if getattr(model, "prefix", "") and getattr(model, "prefix") in name:
                    continue
                if "original_module" in name:
                    continue
                name = name.replace("modules_to_save.default.", "")
                llm_model.load_weights([(name, parameter.data)])
        finally:
            model.unmerge_adapter()
        return

    for name, parameter in model.named_parameters():
        llm_model.load_weights([(name, parameter.data)])


class ColocatedVLLMGenerationClient:
    def __init__(
        self,
        *,
        host: str = "127.0.0.1",
        port: int = 8000,
        timeout_seconds: float = 120.0,
        backend: Any | None = None,
        model_path: str | None = None,
        tensor_parallel_size: int | None = None,
        gpu_memory_utilization: float | None = None,
        max_model_len: int | None = None,
        dtype: str | None = None,
        enable_lora: bool | None = None,
        max_lora_rank: int | None = None,
        quantization: str | None = None,
        load_format: str | None = None,
        enforce_eager: bool | None = None,
    ) -> None:
        del host, port, timeout_seconds
        self.model_path = model_path or os.environ.get("SINGLE_VLLM_MODEL", "model/Qwen2.5-7B-Instruct")
        self.tensor_parallel_size = int(tensor_parallel_size or os.environ.get("SINGLE_VLLM_TP", "1"))
        self.gpu_memory_utilization = float(
            gpu_memory_utilization or os.environ.get("SINGLE_VLLM_GPU_UTIL", "0.3")
        )
        self.max_model_len = int(max_model_len or os.environ.get("SINGLE_VLLM_MAX_LEN", "4096"))
        self.dtype = dtype or os.environ.get("SINGLE_VLLM_DTYPE", "auto")
        self.enable_lora = _as_bool(os.environ.get("SINGLE_VLLM_ENABLE_LORA"), default=bool(enable_lora))
        self.max_lora_rank = _as_optional_int(os.environ.get("SINGLE_VLLM_MAX_LORA_RANK")) or max_lora_rank
        self.quantization = _as_optional_str(os.environ.get("SINGLE_VLLM_QUANTIZATION")) or quantization
        self.load_format = _as_optional_str(os.environ.get("SINGLE_VLLM_LOAD_FORMAT")) or load_format or "auto"
        self.enforce_eager = _as_optional_bool(os.environ.get("SINGLE_VLLM_ENFORCE_EAGER"))
        if self.enforce_eager is None:
            self.enforce_eager = enforce_eager
        self._backend = backend
        self._last_sync_seconds = 0.0

    @property
    def backend(self) -> Any:
        if self._backend is None:
            llm_cls, _ = _load_vllm_classes()
            kwargs: dict[str, Any] = {
                "model": self.model_path,
                "tensor_parallel_size": self.tensor_parallel_size,
                "gpu_memory_utilization": self.gpu_memory_utilization,
                "max_model_len": self.max_model_len,
                "dtype": self.dtype,
                "quantization": self.quantization,
                "load_format": self.load_format,
                "enforce_eager": self.enforce_eager,
            }
            if self.enable_lora:
                kwargs["enable_lora"] = True
            if self.max_lora_rank is not None:
                kwargs["max_lora_rank"] = self.max_lora_rank
            self._backend = llm_cls(**kwargs)
        return self._backend

    def check_server(self) -> None:
        return None

    def validate_lora_server(self, args: Any) -> None:
        del args
        if not self.enable_lora:
            raise SystemExit(
                "rl_single colocate mode does not use the LoRA HTTP server. "
                "Use vllm_sync_mode: dense in src/rl_single/train_grpo_single.yml."
            )

    def generate(
        self,
        prompt: str,
        *,
        max_tokens: int,
        temperature: float,
        top_p: float,
        top_k: int,
    ) -> tuple[list[int], str]:
        _, sampling_params_cls = _load_vllm_classes()
        sampling_params = sampling_params_cls(
            n=1,
            repetition_penalty=1.0,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
        )
        outputs = self.backend.generate([prompt], sampling_params=sampling_params, use_tqdm=False)
        if not outputs or not getattr(outputs[0], "outputs", None):
            return [], ""
        first = outputs[0].outputs[0]
        return list(getattr(first, "token_ids", [])), str(getattr(first, "text", "") or "")

    def sync_trainable_parameters(self, model: Any) -> float:
        start = time.perf_counter()
        _sync_dense_weights_to_vllm(self.backend, model)
        reset_prefix_cache = getattr(self.backend, "reset_prefix_cache", None)
        if callable(reset_prefix_cache):
            _with_logger_errors(("", "vllm"), reset_prefix_cache)
        self._last_sync_seconds = time.perf_counter() - start
        return self._last_sync_seconds

    def sync_lora_parameters(self, model: Any) -> float:
        raise SystemExit(
            "rl_single colocate mode currently syncs merged dense weights, matching TRL colocate behavior. "
            "Set vllm_sync_mode: dense for single-card training."
        )


def _patch_colocated_vllm_client() -> None:
    import rl_single.vllm_client as vllm_client

    vllm_client.VLLMGenerationClient = ColocatedVLLMGenerationClient
    try:
        import rl_single.train_grpo_macorag as entrypoint
    except ModuleNotFoundError:
        return
    entrypoint.VLLMGenerationClient = ColocatedVLLMGenerationClient


def _patch_initial_vllm_sync(entrypoint: Any) -> None:
    if not hasattr(entrypoint, "_build_policy"):
        return
    original_build_policy = entrypoint._build_policy

    def build_policy_with_initial_sync(args: Any, raw_policy_model: Any, tokenizer: Any) -> Any:
        policy = original_build_policy(args, raw_policy_model, tokenizer)
        client = getattr(policy, "vllm_client", None)
        if isinstance(client, ColocatedVLLMGenerationClient):
            if getattr(args, "vllm_sync_mode", "dense") != "dense":
                raise SystemExit(
                    "rl_single colocate mode requires vllm_sync_mode: dense so initial SFT/LoRA weights "
                    "are merged into the embedded vLLM model before rollout."
                )
            if getattr(args, "load_4bit", False):
                raise SystemExit(
                    "rl_single colocate dense sync is incompatible with load_4bit: true because vLLM expects "
                    "dense model-weight shapes. Set load_4bit: false in src/rl_single/train_grpo_single.yml."
                )
            client.sync_trainable_parameters(raw_policy_model)
        return policy

    entrypoint._build_policy = build_policy_with_initial_sync


def _load_entrypoint() -> Any:
    import rl_single.train_grpo_macorag as entrypoint

    return entrypoint


def main() -> None:
    _configure_quiet_console_defaults()
    _sanitize_config_for_single_training()
    _patch_colocated_vllm_client()
    entrypoint = _load_entrypoint()
    entrypoint._validate_vllm_gpu_placement = _skip_vllm_gpu_overlap_check
    entrypoint._validate_local_vllm_server_model = _skip_vllm_gpu_overlap_check
    _patch_initial_vllm_sync(entrypoint)
    entrypoint.main()


if __name__ == "__main__":
    main()
