from __future__ import annotations

import argparse
import os
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SingleGpuLaunchConfig:
    visible_gpu: str
    nproc_per_node: int
    train_env: dict[str, str]
    vllm_env: dict[str, str]
    vllm_args: dict[str, str]


def _load_yaml(path: Path) -> dict[str, Any]:
    try:
        import yaml
    except ModuleNotFoundError as exc:
        raise SystemExit("PyYAML is required to load GRPO YAML config.") from exc
    payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        raise SystemExit(f"Invalid config format at {path}: expected a mapping.")
    return {str(key).replace("-", "_"): value for key, value in payload.items()}


def _value(config: dict[str, Any], key: str, default: Any) -> str:
    value = config.get(key, default)
    return str(value)


def load_single_gpu_launch_config(
    *,
    config_path: str | Path,
    single_gpu_index: str | None = None,
    vllm_gpu_memory_utilization: str | None = None,
) -> SingleGpuLaunchConfig:
    config = _load_yaml(Path(config_path))
    visible_gpu = str(single_gpu_index or os.environ.get("SINGLE_GPU_INDEX") or "0").strip()
    if not visible_gpu:
        raise SystemExit("SINGLE_GPU_INDEX cannot be empty.")

    gpu_util = str(
        vllm_gpu_memory_utilization
        or os.environ.get("SINGLE_VLLM_GPU_MEMORY_UTILIZATION")
        or config.get("vllm_gpu_memory_utilization", 0.75)
    )
    lora_adapter_path = str(config.get("vllm_lora_adapter_path") or config.get("sft_adapter_path", ""))
    vllm_args = {
        "mode": _value(config, "vllm_mode", "colocate"),
        "sync_mode": _value(config, "vllm_sync_mode", "dense"),
        "model": _value(config, "model_path", "model/Qwen2.5-7B-Instruct"),
        "host": _value(config, "vllm_host", "127.0.0.1"),
        "port": _value(config, "vllm_port", 8000),
        "tensor_parallel_size": _value(config, "vllm_tensor_parallel_size", 1),
        "data_parallel_size": _value(config, "vllm_data_parallel_size", 1),
        "gpu_memory_utilization": gpu_util,
        "max_model_len": _value(config, "vllm_max_model_len", 4608),
        "dtype": _value(config, "vllm_dtype", "auto"),
        "lora_name": _value(config, "vllm_lora_name", "macorag_train"),
        "lora_int_id": _value(config, "vllm_lora_int_id", 1),
        "lora_adapter_path": lora_adapter_path,
        "enable_lora": _value(config, "vllm_enable_lora", False),
        "max_lora_rank": _value(config, "vllm_max_lora_rank", ""),
        "quantization": _value(config, "single_vllm_quantization", ""),
        "load_format": _value(config, "single_vllm_load_format", "auto"),
        "enforce_eager": _value(config, "single_vllm_enforce_eager", ""),
    }
    env = {"CUDA_VISIBLE_DEVICES": visible_gpu}
    return SingleGpuLaunchConfig(
        visible_gpu=visible_gpu,
        nproc_per_node=1,
        train_env=dict(env),
        vllm_env=dict(env),
        vllm_args=vllm_args,
    )


def _shell_assign(name: str, value: str) -> str:
    return f"{name}={shlex.quote(value)}"


def print_shell_vars(args: argparse.Namespace) -> None:
    launch = load_single_gpu_launch_config(
        config_path=args.config,
        single_gpu_index=args.single_gpu_index,
        vllm_gpu_memory_utilization=args.vllm_gpu_memory_utilization,
    )
    rows = {
        "SINGLE_VISIBLE_GPU": launch.visible_gpu,
        "SINGLE_NPROC_PER_NODE": str(launch.nproc_per_node),
        "SINGLE_VLLM_SYNC_MODE": launch.vllm_args["sync_mode"],
        "SINGLE_VLLM_MODE": launch.vllm_args["mode"],
        "SINGLE_VLLM_MODEL": launch.vllm_args["model"],
        "SINGLE_VLLM_HOST": launch.vllm_args["host"],
        "SINGLE_VLLM_PORT": launch.vllm_args["port"],
        "SINGLE_VLLM_TP": launch.vllm_args["tensor_parallel_size"],
        "SINGLE_VLLM_DP": launch.vllm_args["data_parallel_size"],
        "SINGLE_VLLM_GPU_UTIL": launch.vllm_args["gpu_memory_utilization"],
        "SINGLE_VLLM_MAX_LEN": launch.vllm_args["max_model_len"],
        "SINGLE_VLLM_DTYPE": launch.vllm_args["dtype"],
        "SINGLE_VLLM_LORA_NAME": launch.vllm_args["lora_name"],
        "SINGLE_VLLM_LORA_INT_ID": launch.vllm_args["lora_int_id"],
        "SINGLE_VLLM_LORA_ADAPTER_PATH": launch.vllm_args["lora_adapter_path"],
        "SINGLE_VLLM_ENABLE_LORA": launch.vllm_args["enable_lora"],
        "SINGLE_VLLM_MAX_LORA_RANK": launch.vllm_args["max_lora_rank"],
        "SINGLE_VLLM_QUANTIZATION": launch.vllm_args["quantization"],
        "SINGLE_VLLM_LOAD_FORMAT": launch.vllm_args["load_format"],
        "SINGLE_VLLM_ENFORCE_EAGER": launch.vllm_args["enforce_eager"],
    }
    for name, value in rows.items():
        print(_shell_assign(name, value))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Emit single-GPU MACORAG RL launch settings.")
    parser.add_argument("--config", default="config/train_grpo.yml")
    parser.add_argument("--single-gpu-index", default=None)
    parser.add_argument("--vllm-gpu-memory-utilization", default=None)
    parser.set_defaults(func=print_shell_vars)
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
