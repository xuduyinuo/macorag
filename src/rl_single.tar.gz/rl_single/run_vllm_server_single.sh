#!/usr/bin/env bash
set -euo pipefail

echo "rl_single uses vLLM colocate mode inside the trainer process; no separate vLLM server is needed."
echo "Run: src/rl_single/run_train_grpo_single.sh"
exit 2
